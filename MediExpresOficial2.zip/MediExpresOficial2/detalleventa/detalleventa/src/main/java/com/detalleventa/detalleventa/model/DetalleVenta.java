package com.detalleventa.detalleventa.model;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;


@Entity
@Table(name = "detalleVenta")

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DetalleVenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long idLong;

    @Column(nullable = false, unique = true)
    private Integer cantidad;
    
    @Column(nullable = false, unique = true)
    private LocalDate fecha;

    @Column
    private String mensaje;


}
