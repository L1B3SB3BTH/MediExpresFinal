package com.detalleventa.detalleventa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.detalleventa.detalleventa.repository.DetalleVentaRepository;
import com.detalleventa.detalleventa.model.DetalleVenta;
import java.util.List;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class DetalleVentaService {

    @Autowired
    private DetalleVentaRepository detalleVentaRepository;

    public List<DetalleVenta> getDetalleVenta(){
        return detalleVentaRepository.findAll();
    }

    public DetalleVenta saveDetalle(DetalleVenta detalle){
        return detalleVentaRepository.save(detalle);
    }

    public DetalleVenta getDetalle(Long idDetalleVenta){
        return detalleVentaRepository.findById(idDetalleVenta)
        .orElseThrow(()-> new RuntimeException("Detalle de venta no encontrado "));

    }

    public void  deleteDetalleVenta(Long idDetalleVenta){
        DetalleVenta dVenta = detalleVentaRepository.findById(idDetalleVenta)
        .orElseThrow(()-> new RuntimeException("No existe un detalle venta con id: " + idDetalleVenta ));

        detalleVentaRepository.delete(dVenta);


    }

   public DetalleVenta actualizarDetalleVenta(Long idDetalleVenta, DetalleVenta nuevosDatos) {
    DetalleVenta existente = detalleVentaRepository.findById(idDetalleVenta)
            .orElseThrow(() -> new RuntimeException("No hay detalle de venta con ID: " + idDetalleVenta));

    existente.setCantidad(nuevosDatos.getCantidad());
    existente.setFecha(nuevosDatos.getFecha());

    return detalleVentaRepository.save(existente);
}



}
