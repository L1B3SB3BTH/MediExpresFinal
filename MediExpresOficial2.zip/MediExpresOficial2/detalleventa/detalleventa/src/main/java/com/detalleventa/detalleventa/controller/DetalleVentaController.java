package com.detalleventa.detalleventa.controller;
import com.detalleventa.detalleventa.service.DetalleVentaService;
import com.detalleventa.detalleventa.model.DetalleVenta;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/DetalleVenta")
public class DetalleVentaController {

    @Autowired
    private DetalleVentaService detalleVentaService;

    // Obtener todos los detalles de venta
    @GetMapping("/obtener")
    public ResponseEntity<?> listarDetallesVenta() {
        try {
            List<DetalleVenta> detalles = detalleVentaService.getDetalleVenta();
            if (detalles.isEmpty()) {
                return ResponseEntity.noContent().build(); // 204
            }
            return ResponseEntity.ok(detalles); // 200
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener los detalles de venta.");
        }
    }

    // Obtener detalle de venta por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerDetallePorId(@PathVariable Long id) {
        try {
            DetalleVenta detalle = detalleVentaService.getDetalle(id);
            return ResponseEntity.ok(detalle); // 200
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error inesperado.");
        }
    }

    // Crear nuevo detalle de venta
    @PostMapping("/nuevo")
    public ResponseEntity<?> crearDetalle(@RequestBody DetalleVenta nuevoDetalle) {
        try {
            DetalleVenta creado = detalleVentaService.saveDetalle(nuevoDetalle);
            return ResponseEntity.status(HttpStatus.CREATED).body(creado); // 201
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear el detalle de venta: " + e.getMessage());
        }
    }

    // Actualizar detalle de venta existente
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarDetalle(@PathVariable Long id, @RequestBody DetalleVenta detalleActualizado) {
        try {
            DetalleVenta actualizado = detalleVentaService.actualizarDetalleVenta(id, detalleActualizado);
            return ResponseEntity.ok(actualizado); // 200
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al actualizar el detalle de venta: " + e.getMessage());
        }
    }

    // Eliminar detalle de venta por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarDetalle(@PathVariable Long id) {
        try {
            detalleVentaService.deleteDetalleVenta(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar el detalle de venta.");
        }
    }



}
