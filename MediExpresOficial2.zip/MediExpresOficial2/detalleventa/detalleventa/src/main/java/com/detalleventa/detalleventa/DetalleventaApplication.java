package com.detalleventa.detalleventa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetalleventaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DetalleventaApplication.class, args);
	}

}
