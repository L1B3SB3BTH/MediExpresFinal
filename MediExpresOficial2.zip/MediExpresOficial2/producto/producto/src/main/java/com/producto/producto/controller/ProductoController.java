package com.producto.producto.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;//usar imports especificos como import org.springframework.web.bind.annotation.RestController;

import com.producto.producto.model.Producto;
import com.producto.producto.service.ProductoService;

@RestController
@RequestMapping("/api/Producto")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    //  Obtener todos los productos
    @GetMapping("/obtener")
    public ResponseEntity<?> listarProductos() {
        try {
            List<Producto> productos = productoService.getProductos();
            if (productos.isEmpty()) {
                return ResponseEntity.noContent().build(); // 204 No Content
            }
            return ResponseEntity.ok(productos); // 200 OK
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener los productos.");
        }
    }

    //  Obtener un producto por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerProducto(@PathVariable Long id) {
        try {
            Producto producto = productoService.getProducto(id);
            return ResponseEntity.ok(producto); // 200 OK
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error inesperado al buscar el producto.");
        }
    }

    //  Crear un nuevo producto
    @PostMapping("/nuevo")
    public ResponseEntity<?> crearProducto(@RequestBody Producto nuevoProducto) {
        try {
            Producto creado = productoService.saveProducto(nuevoProducto);
            return ResponseEntity.status(HttpStatus.CREATED).body(creado); // 201 Created
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear el producto: " + e.getMessage());
        }
    }

    //  Actualizar un producto existente
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarProducto(@PathVariable Long id, @RequestBody Producto productoActualizado) {
        try {
            Producto actualizado = productoService.updateProducto(id, productoActualizado);
            return ResponseEntity.ok(actualizado); // 200 OK
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al actualizar el producto: " + e.getMessage());
        }
    }

    //  Eliminar un producto
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarProducto(@PathVariable Long id) {
        try {
            productoService.deleteProducto(id);
            return ResponseEntity.noContent().build(); // 204 No Content
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar el producto.");
        }
    }

    


}
