package com.producto.producto.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.producto.producto.model.Producto;
import com.producto.producto.repository.ProductoRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class ProductoService {

      @Autowired
    private ProductoRepository productoRepository;

    // Obtener todos los productos
    public List<Producto> getProductos() {
        return productoRepository.findAll();
    }

    // Obtener un producto por ID
    public Producto getProducto(Long idProducto) {
        return productoRepository.findById(idProducto)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + idProducto));
    }

    // Guardar un nuevo producto
    public Producto saveProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    // Actualizar un producto existente
    public Producto updateProducto(Long idProducto, Producto productoActualizado) {
        Producto productoExistente = productoRepository.findById(idProducto)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + idProducto));

        // Actualiza campos relevantes
        productoExistente.setDescripcion(productoActualizado.getDescripcion());
        productoExistente.setUnidad(productoActualizado.getUnidad());
        productoExistente.setStock(productoActualizado.getStock());
        productoExistente.setFechaCaducidad(productoActualizado.getFechaCaducidad());

        return productoRepository.save(productoExistente);
    }

    // Eliminar un producto
    public void deleteProducto(Long idProducto) {
        if (!productoRepository.existsById(idProducto)) {
            throw new RuntimeException("Producto no encontrado con ID: " + idProducto);
        }
        productoRepository.deleteById(idProducto);
    }


}
