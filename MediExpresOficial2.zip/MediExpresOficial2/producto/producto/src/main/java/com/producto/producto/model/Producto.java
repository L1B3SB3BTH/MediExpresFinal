package com.producto.producto.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "Producto")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProducto;
    @Column(nullable = false, length = 200)
    private String Descripcion;
    @Column(nullable = false)
    private int Unidad;
    @Column(nullable = false)
    private int Stock;
    @Column(nullable = false)
    private LocalDate fechaCaducidad;

}
