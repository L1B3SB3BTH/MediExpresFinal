package com.estado.estado.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import com.estado.estado.model.Estado;
import com.estado.estado.repository.EstadoRepository;
import java.util.List;

@Service
@Transactional
public class EstadoService {

    @Autowired
    private EstadoRepository estadoRepository;

    // Obtener todos los estados
    public List<Estado> getEstados() {
        return estadoRepository.findAll();
    }

    // Obtener un estado por ID
    public Estado getEstado(Long idEstado) {
        return estadoRepository.findById(idEstado)
            .orElseThrow(() -> new RuntimeException("Estado no encontrado con ID: " + idEstado));
    }

    // Guardar un nuevo estado
    public Estado saveEstado(Estado estado) {
        return estadoRepository.save(estado);
    }

    // Actualizar un estado existente
    public Estado updateEstado(Long idEstado, Estado estadoActualizado) {
        Estado estadoExistente = estadoRepository.findById(idEstado)
            .orElseThrow(() -> new RuntimeException("Estado no encontrado con ID: " + idEstado));

        estadoExistente.setNombre(estadoActualizado.getNombre());

        return estadoRepository.save(estadoExistente);
    }

    // Eliminar un estado
    public void deleteEstado(Long idEstado) {
        if (!estadoRepository.existsById(idEstado)) {
            throw new RuntimeException("Estado no encontrado con ID: " + idEstado);
        }
        estadoRepository.deleteById(idEstado);
    }

}
