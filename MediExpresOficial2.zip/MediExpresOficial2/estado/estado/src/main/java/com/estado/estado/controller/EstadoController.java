package com.estado.estado.controller;
import com.estado.estado.model.Estado;
import com.estado.estado.service.EstadoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/estado")
public class EstadoController {

    @Autowired
    private EstadoService estadoService;

    //  Obtener todos los estados
    @GetMapping("/obtener")
    public ResponseEntity<?> listarEstados() {
        try {
            List<Estado> estados = estadoService.getEstados();
            if (estados.isEmpty()) {
                return ResponseEntity.noContent().build(); // 204
            }
            return ResponseEntity.ok(estados); // 200
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener los estados.");
        }
    }

    //  Obtener estado por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerEstadoPorId(@PathVariable Long id) {
        try {
            Estado estado = estadoService.getEstado(id);
            return ResponseEntity.ok(estado);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error inesperado.");
        }
    }

    //  Crear nuevo estado
    @PostMapping("/nuevo")
    public ResponseEntity<?> crearEstado(@RequestBody Estado nuevoEstado) {
        try {
            Estado creado = estadoService.saveEstado(nuevoEstado);
            return ResponseEntity.status(HttpStatus.CREATED).body(creado); // 201
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear estado: " + e.getMessage());
        }
    }

    //  Actualizar estado existente
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarEstado(@PathVariable Long id, @RequestBody Estado estadoActualizado) {
        try {
            Estado actualizado = estadoService.updateEstado(id, estadoActualizado);
            return ResponseEntity.ok(actualizado); // 200
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al actualizar el estado: " + e.getMessage());
        }
    }

    //  Eliminar estado por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarEstado(@PathVariable Long id) {
        try {
            estadoService.deleteEstado(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar el estado.");
        }
    }


}
