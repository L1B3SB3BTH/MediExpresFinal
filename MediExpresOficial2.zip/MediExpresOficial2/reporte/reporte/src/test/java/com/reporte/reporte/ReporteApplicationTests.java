package com.reporte.reporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReporteApplicationTests {

	@Test
	void contextLoads() {
	}

}
