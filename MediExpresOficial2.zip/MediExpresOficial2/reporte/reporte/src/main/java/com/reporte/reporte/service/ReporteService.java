package com.reporte.reporte.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import com.reporte.reporte.repository.ReporteRepository;
import com.reporte.reporte.model.Reporte;
import java.util.List;



@Service
@Transactional
public class ReporteService {

    @Autowired
    private ReporteRepository reporteRepository;
    
    public List<Reporte> getReportes() {
        return reporteRepository.findAll();
    }

    public Reporte saveReporte(Reporte reporte) {
        return reporteRepository.save(reporte);
    }

    public Reporte getReporte(Long idReporte) {
        return reporteRepository.findById(idReporte)
            .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));
    }

    public void deleteReporte(Long idReporte) {
        Reporte reporte = reporteRepository.findById(idReporte)
            .orElseThrow(() -> new RuntimeException("No existe un reporte Registrado con " + idReporte));

        reporteRepository.delete(reporte);
    }

    public Reporte updateReporte(Long idReporte, Reporte estadoActualizado) {
        Reporte reporteExistente = reporteRepository.findById(idReporte)
            .orElseThrow(() -> new RuntimeException("Reporte no encontrado con ID: " + idReporte));

        reporteExistente.setMensaje(estadoActualizado.getMensaje());
        return reporteRepository.save(reporteExistente);
    }

    
}









    


