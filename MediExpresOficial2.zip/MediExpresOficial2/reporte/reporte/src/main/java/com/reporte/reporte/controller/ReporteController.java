package com.reporte.reporte.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.reporte.reporte.model.Reporte;
import com.reporte.reporte.service.ReporteService;

import java.util.List;

@RestController
@RequestMapping("/api/reporte")
public class ReporteController {

    @Autowired
    private ReporteService reporteService;

    // Obtener todos los reportes
    @GetMapping("/obtener")
    public ResponseEntity<?> listarReportes() {
        try {
            List<Reporte> reportes = reporteService.getReportes();
            if (reportes.isEmpty()) {
                return ResponseEntity.noContent().build(); // 204
            }
            return ResponseEntity.ok(reportes); // 200
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener los reportes.");
        }
    }

    // Obtener reporte por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerReportePorId(@PathVariable Long id) {
        try {
            Reporte reporte = reporteService.getReporte(id);
            return ResponseEntity.ok(reporte); // 200
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error inesperado.");
        }
    }

    // Crear nuevo reporte
    @PostMapping("/nuevo")
    public ResponseEntity<?> crearReporte(@RequestBody Reporte nuevoReporte) {
        try {
            Reporte creado = reporteService.saveReporte(nuevoReporte);
            return ResponseEntity.status(HttpStatus.CREATED).body(creado); // 201
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear el reporte: " + e.getMessage());
        }
    }

    // Actualizar reporte existente
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarReporte(@PathVariable Long id, @RequestBody Reporte reporteActualizado) {
        try {
            Reporte actualizado = reporteService.updateReporte(id, reporteActualizado);
            return ResponseEntity.ok(actualizado); // 200
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al actualizar el reporte: " + e.getMessage());
        }
    }

    // Eliminar reporte por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarReporte(@PathVariable Long id) {
        try {
            reporteService.deleteReporte(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar el reporte.");
        }
    }

}
