package com.reporte.reporte.model;
import jakarta.persistence.*;//mapea las clases de las base de datos
import lombok.AllArgsConstructor;
import lombok.Data;//genera getters,setter entre otros
import lombok.NoArgsConstructor;
import java.time.LocalDate;



@Entity
@Table(name = "reporte")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Reporte {

    @Id//hace que se identifica como pk
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idReporte;

    @Column(unique = true, nullable = false, length = 500)
    private String mensaje;

    @Column(name = "Fecha_emision", nullable = false)
    private LocalDate fecha;
}
