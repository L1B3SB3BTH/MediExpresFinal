package com.venta.venta.controllertest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.venta.venta.controller.VentaController;
import com.venta.venta.model.Venta;
import com.venta.venta.service.VentaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;



@WebMvcTest(VentaController.class)
class VentaControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VentaService ventaService;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        // para asegurarnos de serializar LocalDate correctamente
        objectMapper.registerModule(new JavaTimeModule());
    }

    private Venta ejemploVenta() {
        return new Venta(
            1L,
            LocalDate.of(2025, 7, 9),
            500  // Total de la venta
        );
    }

    @Test
    @DisplayName("GET /api/Venta/obtener → 204 No Content cuando no hay ventas")
    void listarVentasVacio() throws Exception {
        Mockito.when(ventaService.getVentas())
               .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/Venta/obtener"))
               .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("GET /api/Venta/obtener → 200 OK y devuelve lista de Ventas")
    void listarVentas() throws Exception {
        List<Venta> lista = List.of(ejemploVenta());
        Mockito.when(ventaService.getVentas())
               .thenReturn(lista);

        mockMvc.perform(get("/api/Venta/obtener"))
               .andExpect(status().isOk())
               .andExpect(content().contentType(MediaType.APPLICATION_JSON))
               .andExpect(jsonPath("$", hasSize(1)))
               .andExpect(jsonPath("$[0].idVenta", is(1)))
               .andExpect(jsonPath("$[0].fechaVenta", is("2025-07-09")))
               .andExpect(jsonPath("$[0].total", is(500)));
    }

    @Test
    @DisplayName("GET /api/Venta/{id} → 200 OK cuando la venta existe")
    void obtenerVentaPorIdOk() throws Exception {
        Venta v = ejemploVenta();
        Mockito.when(ventaService.getVenta(1L))
               .thenReturn(v);

        mockMvc.perform(get("/api/Venta/{id}", 1L))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.idVenta", is(1)))
               .andExpect(jsonPath("$.fechaVenta", is("2025-07-09")))
               .andExpect(jsonPath("$.total", is(500)));
    }

    @Test
    @DisplayName("GET /api/Venta/{id} → 404 Not Found cuando no existe")
    void obtenerVentaPorIdNotFound() throws Exception {
        Mockito.when(ventaService.getVenta(99L))
               .thenThrow(new RuntimeException("Venta no encontrada con ID: 99"));

        mockMvc.perform(get("/api/Venta/{id}", 99L))
               .andExpect(status().isNotFound())
               .andExpect(content().string(containsString("Venta no encontrada con ID: 99")));
    }

    @Test
    @DisplayName("POST /api/Venta/crear → 201 Created y devuelve la venta creada")
    void crearVenta() throws Exception {
        Venta v = ejemploVenta();
        Mockito.when(ventaService.saveVenta(any(Venta.class)))
               .thenReturn(v);

        mockMvc.perform(post("/api/Venta/crear")
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(v)))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.idVenta", is(1)))
               .andExpect(jsonPath("$.fechaVenta", is("2025-07-09")))
               .andExpect(jsonPath("$.total", is(500)));
    }

    @Test
    @DisplayName("PUT /api/Venta/{id} → 200 OK y actualiza la venta")
    void actualizarVenta() throws Exception {
        // cargo solo el campo que quiero cambiar (Total)
        Venta cambios = new Venta(null, null, 750);
        Venta actualizado = ejemploVenta();
        actualizado.setTotal(750);

        Mockito.when(ventaService.updateVenta(eq(1L), any(Venta.class)))
               .thenReturn(actualizado);

        mockMvc.perform(put("/api/Venta/{id}", 1L)
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(cambios)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.total", is(750)));
    }

    @Test
    @DisplayName("DELETE /api/Venta/{id} → 204 No Content al eliminar")
    void eliminarVenta() throws Exception {
        Mockito.doNothing().when(ventaService).deleteVenta(1L);

        mockMvc.perform(delete("/api/Venta/{id}", 1L))
               .andExpect(status().isNoContent());
    }





}
