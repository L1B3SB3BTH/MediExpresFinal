package com.venta.venta.ventaservicetest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.venta.venta.repository.VentaRepository;
import com.venta.venta.service.VentaService;
import com.venta.venta.model.Venta;
import java.util.*;

@ExtendWith(MockitoExtension.class)
public class VentaServiceTest {

    @Mock
    private VentaRepository ventaRepository;

    @InjectMocks
    private VentaService ventaService;

   private Venta venta;

   @BeforeEach
   void setUp(){
    venta = new Venta(1L,LocalDate.of(2025,01,01),1000);
   }

   //test 1 obtener ventas;
   @Test 
   void testGetVentas(){

        List<Venta> ventas = Arrays.asList(venta, new Venta(2L, LocalDate.now(), 15000));
        when(ventaRepository.findAll()).thenReturn(ventas);

        List<Venta> resultado = ventaService.getVentas();

        assertEquals(2, resultado.size());
        verify(ventaRepository).findAll();
   }

    // 2. Obtener todas las ventas cuando lista está vacía
    @Test
    void testGetVentasVacia() {
        when(ventaRepository.findAll()).thenReturn(Collections.emptyList());

        List<Venta> resultado = ventaService.getVentas();

        assertTrue(resultado.isEmpty());
        verify(ventaRepository).findAll();
    }

    // 3. Obtener venta por ID (existe)
    @Test
    void testGetVentaExistente() {
        when(ventaRepository.findById(1L)).thenReturn(Optional.of(venta));

        Venta resultado = ventaService.getVenta(1L);

        assertEquals(venta.getTotal(), resultado.getTotal());
        verify(ventaRepository).findById(1L);
    }

    // 4. Obtener venta por ID (no existe)
    @Test
    void testGetVentaNoExistente() {
        when(ventaRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            ventaService.getVenta(1L);
        });

        assertEquals("Venta no encontrada con ID: 1", ex.getMessage());
    }

    // 5. Guardar nueva venta
    @Test
    void testSaveVenta() {
        Venta nueva = new Venta(null, LocalDate.of(2025, 1, 1), 20000);
        Venta guardada = new Venta(1L, nueva.getFechaVenta(), nueva.getTotal());

        when(ventaRepository.save(nueva)).thenReturn(guardada);

        Venta resultado = ventaService.saveVenta(nueva);

        assertNotNull(resultado.getIdVenta());
        assertEquals(20000, resultado.getTotal());
        verify(ventaRepository).save(nueva);
    }

    // 6. Actualizar venta existente
    @Test
    void testUpdateVentaExistente() {
        Venta actualizada = new Venta(null, LocalDate.of(2026, 2, 2), 30000);

        when(ventaRepository.findById(1L)).thenReturn(Optional.of(venta));
        when(ventaRepository.save(any(Venta.class))).thenAnswer(inv -> inv.getArgument(0));

        Venta resultado = ventaService.updateVenta(1L, actualizada);

        assertEquals(30000, resultado.getTotal());
        assertEquals(LocalDate.of(2026, 2, 2), resultado.getFechaVenta());
        verify(ventaRepository).save(venta);
    }

    // 7. Actualizar venta que no existe
    @Test
    void testUpdateVentaNoExistente() {
        when(ventaRepository.findById(99L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            ventaService.updateVenta(99L, venta);
        });

        assertEquals("Venta no encontrada con ID: 99", ex.getMessage());
    }

    // 8. Eliminar venta existente
    @Test
    void testDeleteVentaExistente() {
        when(ventaRepository.existsById(1L)).thenReturn(true);
        doNothing().when(ventaRepository).deleteById(1L);

        ventaService.deleteVenta(1L);

        verify(ventaRepository).deleteById(1L);
    }

    // 9. Eliminar venta que no existe
    @Test
    void testDeleteVentaNoExistente() {
        when(ventaRepository.existsById(1L)).thenReturn(false);

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            ventaService.deleteVenta(1L);
        });

        assertEquals("Venta no encontrada con ID: 1", ex.getMessage());
    }

}

