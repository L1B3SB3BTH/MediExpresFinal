package com.venta.venta.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import com.venta.venta.model.Venta;
import com.venta.venta.repository.VentaRepository;

@Service
@Transactional
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    // Obtener todas las ventas
    public List<Venta> getVentas() {
        return ventaRepository.findAll();
    }

    // Obtener una venta por ID
    public Venta getVenta(Long idVenta) {
        return ventaRepository.findById(idVenta)
                .orElseThrow(() -> new RuntimeException("Venta no encontrada con ID: " + idVenta));
    }

    // Guardar una nueva venta
    public Venta saveVenta(Venta venta) {
        return ventaRepository.save(venta);
    }

    // Actualizar una venta existente
    public Venta updateVenta(Long idVenta, Venta ventaActualizada) {
        Venta ventaExistente = ventaRepository.findById(idVenta)
                .orElseThrow(() -> new RuntimeException("Venta no encontrada con ID: " + idVenta));

        // Actualiza los campos relevantes
        ventaExistente.setFechaVenta(ventaActualizada.getFechaVenta());
        ventaExistente.setTotal(ventaActualizada.getTotal());

        return ventaRepository.save(ventaExistente);
    }

    // Eliminar una venta
    public void deleteVenta(Long idVenta) {
        if (!ventaRepository.existsById(idVenta)) {
            throw new RuntimeException("Venta no encontrada con ID: " + idVenta);
        }
        ventaRepository.deleteById(idVenta);
    }

}
