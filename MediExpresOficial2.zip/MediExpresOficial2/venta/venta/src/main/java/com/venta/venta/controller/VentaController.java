package com.venta.venta.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.venta.venta.model.Venta;
import com.venta.venta.service.VentaService;

@RestController
@RequestMapping("/api/Venta")
public class VentaController {
    
    @Autowired
    private VentaService ventaService;

    //  Obtener todas las ventas
    @GetMapping("/obtener")
    public ResponseEntity<?> listarVentas() {
        try {
            List<Venta> ventas = ventaService.getVentas();
            if (ventas.isEmpty()) {
                return ResponseEntity.noContent().build(); // 204 No Content
            }
            return ResponseEntity.ok(ventas); // 200 OK
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener las ventas.");
        }
    }

    //  Obtener una venta por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerVenta(@PathVariable Long id) {
        try {
            Venta venta = ventaService.getVenta(id);
            return ResponseEntity.ok(venta); // 200 OK
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error inesperado al buscar la venta.");
        }
    }

    //  Crear una nueva venta
    @PostMapping("/crear")
    public ResponseEntity<?> crearVenta(@RequestBody Venta nuevaVenta) {
        try {
            Venta creada = ventaService.saveVenta(nuevaVenta);
            return ResponseEntity.status(HttpStatus.CREATED).body(creada); // 201 Created
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear la venta: " + e.getMessage());
        }
    }

    // Actualizar una venta existente
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarVenta(@PathVariable Long id, @RequestBody Venta ventaActualizada) {
        try {
            Venta actualizada = ventaService.updateVenta(id, ventaActualizada);
            return ResponseEntity.ok(actualizada); // 200 OK
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al actualizar la venta: " + e.getMessage());
        }
    }

    //  Eliminar una venta
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarVenta(@PathVariable Long id) {
        try {
            ventaService.deleteVenta(id);
            return ResponseEntity.noContent().build(); // 204 No Content
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar la venta.");
        }
    }


}
