package com.incidencia.incidencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncidenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
