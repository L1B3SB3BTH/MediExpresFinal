package com.incidencia.incidencia.repository;
import com.incidencia.incidencia.model.Incidencias;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidenciasRepository extends  JpaRepository<Incidencias, Long> {

}
