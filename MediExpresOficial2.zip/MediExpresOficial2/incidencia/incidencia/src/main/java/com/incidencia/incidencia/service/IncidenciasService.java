package com.incidencia.incidencia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import com.incidencia.incidencia.model.Incidencias;
import com.incidencia.incidencia.repository.IncidenciasRepository;

@Service
public class IncidenciasService {

    @Autowired
    private IncidenciasRepository incidenciasRepository;

    // Obtener todas las incidencias
    public List<Incidencias> getIncidencias() {
        return incidenciasRepository.findAll();
    }

    // Guardar una nueva incidencia
    public Incidencias saveIncidencia(Incidencias incidencia) {
        return incidenciasRepository.save(incidencia);
    }

    // Obtener una incidencia por ID
    public Incidencias getIncidencia(Long idIncidencias) {
        return incidenciasRepository.findById(idIncidencias)
            .orElseThrow(() -> new RuntimeException("Incidencia no encontrada con ID: " + idIncidencias));
    }

    // Eliminar una incidencia por ID
    public void deleteIncidencia(Long idIncidencias) {
        Incidencias incidencia = incidenciasRepository.findById(idIncidencias)
            .orElseThrow(() -> new RuntimeException("Incidencia no encontrada con ID: " + idIncidencias));

        incidenciasRepository.delete(incidencia);
    }

    // Actualizar una incidencia existente
    public Incidencias updateIncidencia(Long idIncidencias, Incidencias incidenciaActualizada) {
        Incidencias existente = incidenciasRepository.findById(idIncidencias)
            .orElseThrow(() -> new RuntimeException("Incidencia no encontrada con ID: " + idIncidencias));

        existente.setComentario(incidenciaActualizada.getComentario());
        existente.setFecha(incidenciaActualizada.getFecha());

        return incidenciasRepository.save(existente);
    }

}
