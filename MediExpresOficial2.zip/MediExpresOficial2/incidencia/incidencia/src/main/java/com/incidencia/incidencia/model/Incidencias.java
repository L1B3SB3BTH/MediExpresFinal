package com.incidencia.incidencia.model;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "incidencias")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Incidencias {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idIncidencias;

    @Column(unique = true,nullable = false, length= 150)
    private String comentario;

    @Column(name = "Fecha_emision", nullable = false)
    private LocalDate fecha;



}
