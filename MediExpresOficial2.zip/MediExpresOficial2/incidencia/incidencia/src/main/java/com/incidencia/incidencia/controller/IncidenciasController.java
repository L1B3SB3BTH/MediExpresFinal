package com.incidencia.incidencia.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.incidencia.incidencia.model.Incidencias;
import com.incidencia.incidencia.service.IncidenciasService;

@Controller
@RequestMapping("/api/incidencias")
public class IncidenciasController {

    @Autowired 
    private IncidenciasService incidenciasService;

    @GetMapping("/obtener")
    public ResponseEntity<?> listarIncidencias() {
        try {
            List<Incidencias> lista = incidenciasService.getIncidencias();
            if (lista.isEmpty()) {
                return ResponseEntity.noContent().build(); // 204
            }
            return ResponseEntity.ok(lista); // 200
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener las incidencias.");
        }
    }

    // Obtener incidencia por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerIncidenciaPorId(@PathVariable Long id) {
        try {
            Incidencias incidencia = incidenciasService.getIncidencia(id);
            return ResponseEntity.ok(incidencia);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error inesperado.");
        }
    }

    // Crear nueva incidencia
    @PostMapping("/nuevo")
    public ResponseEntity<?> crearIncidencia(@RequestBody Incidencias nuevaIncidencia) {
        try {
            Incidencias creada = incidenciasService.saveIncidencia(nuevaIncidencia);
            return ResponseEntity.status(HttpStatus.CREATED).body(creada); // 201
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear la incidencia: " + e.getMessage());
        }
    }

    // Actualizar incidencia existente
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarIncidencia(@PathVariable Long id, @RequestBody Incidencias incidenciaActualizada) {
        try {
            Incidencias actualizada = incidenciasService.updateIncidencia(id, incidenciaActualizada);
            return ResponseEntity.ok(actualizada); // 200
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al actualizar la incidencia: " + e.getMessage());
        }
    }

    // Eliminar incidencia por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarIncidencia(@PathVariable Long id) {
        try {
            incidenciasService.deleteIncidencia(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar la incidencia.");
        }
    }

}
