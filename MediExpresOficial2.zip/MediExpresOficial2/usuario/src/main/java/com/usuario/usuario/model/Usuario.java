package com.usuario.usuario.model;
import jakarta.persistence.*;
import java.time.LocalDate;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity//identifica clase como entidad
@Table(name = "usuario")//se identifica como tabla en una base de datos
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idUsuario;
    @Column(name = "fechaCreacion", nullable = false )
    private LocalDate fechaCreacion;//LocalDate permite trabajar solo con la fecha
    @Column(unique = true, nullable = false, length = 15)
    private String correo;
    @Column(unique = true, nullable = false, length = 15)
    private String contraseña;
  
    

}
