package com.usuario.usuario.service;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.usuario.usuario.model.Usuario;
import com.usuario.usuario.repository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> getUsuarios() {
        return usuarioRepository.findAll();
    }

    public Usuario saveUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Usuario getUsuario(Long idUsuario) {
        return usuarioRepository.findById(idUsuario)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + idUsuario));
    }

    public void deleteUsuario(Long idUsuario) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
            .orElseThrow(() -> new RuntimeException("No existe un usuario registrado con ID: " + idUsuario));

        usuarioRepository.delete(usuario);
    }

    public Usuario updateUsuario(Long idUsuario, Usuario datosActualizados) {
        Usuario usuarioExistente = usuarioRepository.findById(idUsuario)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + idUsuario));

        usuarioExistente.setCorreo(datosActualizados.getCorreo());
        usuarioExistente.setContraseña(datosActualizados.getContraseña());  
        usuarioExistente.setFechaCreacion(datosActualizados.getFechaCreacion());

        return usuarioRepository.save(usuarioExistente);
    }


}




