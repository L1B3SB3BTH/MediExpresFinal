package com.usuario.usuario.servicetest;
import com.usuario.usuario.model.Usuario;
import com.usuario.usuario.repository.UsuarioRepository;
import com.usuario.usuario.service.UsuarioService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario usuario1;
    private Usuario usuario2;

    @BeforeEach
    void init() {
        usuario1 = new Usuario(1L,
                               LocalDate.of(2025, 7, 9),
                               "ana@mail.com",
                               "pwd123");
        usuario2 = new Usuario(2L,
                               LocalDate.of(2025, 7, 10),
                               "juan@mail.com",
                               "pass456");
    }

    @Test
    @DisplayName("getUsuarios → retorna lista vacía si no hay usuarios")
    void getUsuarios_emptyList() {
        when(usuarioRepository.findAll()).thenReturn(Collections.emptyList());

        List<Usuario> result = usuarioService.getUsuarios();

        assertTrue(result.isEmpty());
        verify(usuarioRepository).findAll();
    }

    @Test
    @DisplayName("getUsuarios → retorna todos los usuarios")
    void getUsuarios_nonEmptyList() {
        when(usuarioRepository.findAll()).thenReturn(List.of(usuario1, usuario2));

        List<Usuario> result = usuarioService.getUsuarios();

        assertEquals(2, result.size());
        assertEquals("ana@mail.com", result.get(0).getCorreo());
        verify(usuarioRepository).findAll();
    }

    @Test
    @DisplayName("saveUsuario → guarda y retorna el usuario")
    void saveUsuario() {
        when(usuarioRepository.save(usuario1)).thenReturn(usuario1);

        Usuario saved = usuarioService.saveUsuario(usuario1);

        assertSame(usuario1, saved);
        verify(usuarioRepository).save(usuario1);
    }

    @Test
    @DisplayName("getUsuario → retorna usuario existente")
    void getUsuario_found() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario1));

        Usuario found = usuarioService.getUsuario(1L);

        assertEquals("ana@mail.com", found.getCorreo());
        verify(usuarioRepository).findById(1L);
    }

    @Test
    @DisplayName("getUsuario → lanza excepción si no existe")
    void getUsuario_notFound() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class,
            () -> usuarioService.getUsuario(99L));

        assertTrue(ex.getMessage().contains("Usuario no encontrado con ID: 99"));
        verify(usuarioRepository).findById(99L);
    }

    @Test
    @DisplayName("deleteUsuario → elimina usuario existente")
    void deleteUsuario_found() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario1));
        doNothing().when(usuarioRepository).delete(usuario1);

        assertDoesNotThrow(() -> usuarioService.deleteUsuario(1L));
        verify(usuarioRepository).findById(1L);
        verify(usuarioRepository).delete(usuario1);
    }

    @Test
    @DisplayName("deleteUsuario → lanza excepción si no existe")
    void deleteUsuario_notFound() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class,
            () -> usuarioService.deleteUsuario(99L));

        assertTrue(ex.getMessage()
                      .contains("No existe un usuario registrado con ID: 99"));
        verify(usuarioRepository).findById(99L);
        verify(usuarioRepository, never()).delete(any());
    }

    @Test
    @DisplayName("updateUsuario → actualiza y guarda usuario existente")
    void updateUsuario_found() {
        Usuario cambios = new Usuario(null,
                                      LocalDate.of(2025, 7, 11),
                                      "nuevo@mail.com",
                                      "newPwd");
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario1));
        when(usuarioRepository.save(usuario1)).thenReturn(usuario1);

        Usuario updated = usuarioService.updateUsuario(1L, cambios);

        assertEquals("nuevo@mail.com", updated.getCorreo());
        assertEquals("newPwd", updated.getContraseña());
        assertEquals(LocalDate.of(2025, 7, 11),
                     updated.getFechaCreacion());
        verify(usuarioRepository).findById(1L);
        verify(usuarioRepository).save(usuario1);
    }

    @Test
    @DisplayName("updateUsuario → lanza excepción si no existe")
    void updateUsuario_notFound() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class,
            () -> usuarioService.updateUsuario(99L, usuario2));

        assertTrue(ex.getMessage()
                      .contains("Usuario no encontrado con ID: 99"));
        verify(usuarioRepository).findById(99L);
        verify(usuarioRepository, never()).save(any());
    }





}
