package com.usuario.usuario.controllertest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.usuario.usuario.controller.UsuarioController;
import com.usuario.usuario.model.Usuario;
import com.usuario.usuario.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;



@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Registrar módulo para LocalDate
        objectMapper.registerModule(new JavaTimeModule());
    }

    private Usuario ejemploUsuario() {
        return new Usuario(
            1L,
            LocalDate.of(2025, 7, 9),
            "usuario@mail.com",
            "secret"
        );
    }

    @Test
    @DisplayName("GET /api/usuario/obtener → 204 No Content si no hay usuarios")
    void listarUsuariosVacio() throws Exception {
        Mockito.when(usuarioService.getUsuarios())
               .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/usuario/obtener"))
               .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("GET /api/usuario/obtener → 200 OK y lista de usuarios")
    void listarUsuarios() throws Exception {
        List<Usuario> lista = List.of(ejemploUsuario());
        Mockito.when(usuarioService.getUsuarios())
               .thenReturn(lista);

        mockMvc.perform(get("/api/usuario/obtener"))
               .andExpect(status().isOk())
               .andExpect(content().contentType(MediaType.APPLICATION_JSON))
               .andExpect(jsonPath("$", hasSize(1)))
               .andExpect(jsonPath("$[0].idUsuario", is(1)))
               .andExpect(jsonPath("$[0].fechaCreacion", is("2025-07-09")))
               .andExpect(jsonPath("$[0].correo", is("usuario@mail.com")))
               .andExpect(jsonPath("$[0]['contraseña']", is("secret")));
    }

    @Test
    @DisplayName("GET /api/usuario/{id} → 200 OK si el usuario existe")
    void obtenerUsuarioPorIdOk() throws Exception {
        Usuario u = ejemploUsuario();
        Mockito.when(usuarioService.getUsuario(1L))
               .thenReturn(u);

        mockMvc.perform(get("/api/usuario/{id}", 1L))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.idUsuario", is(1)))
               .andExpect(jsonPath("$.fechaCreacion", is("2025-07-09")))
               .andExpect(jsonPath("$.correo", is("usuario@mail.com")))
               .andExpect(jsonPath("$['contraseña']", is("secret")));
    }

    @Test
    @DisplayName("GET /api/usuario/{id} → 404 Not Found si no existe")
    void obtenerUsuarioPorIdNotFound() throws Exception {
        Mockito.when(usuarioService.getUsuario(99L))
               .thenThrow(new RuntimeException("Usuario no encontrado con ID: 99"));

        mockMvc.perform(get("/api/usuario/{id}", 99L))
               .andExpect(status().isNotFound())
               .andExpect(content().string("Usuario no encontrado con ID: 99"));
    }

    @Test
    @DisplayName("POST /api/usuario/nuevo → 201 Created y devuelve el usuario creado")
    void crearUsuario() throws Exception {
        Usuario u = ejemploUsuario();
        Mockito.when(usuarioService.saveUsuario(any(Usuario.class)))
               .thenReturn(u);

        mockMvc.perform(post("/api/usuario/nuevo")
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(u)))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.idUsuario", is(1)))
               .andExpect(jsonPath("$.fechaCreacion", is("2025-07-09")))
               .andExpect(jsonPath("$.correo", is("usuario@mail.com")))
               .andExpect(jsonPath("$['contraseña']", is("secret")));
    }

    @Test
    @DisplayName("PUT /api/usuario/{id} → 200 OK y actualiza el usuario")
    void actualizarUsuario() throws Exception {
        Usuario cambios = new Usuario(null, null, "nuevo@mail.com", "pwd");
        Usuario actualizado = ejemploUsuario();
        actualizado.setCorreo("nuevo@mail.com");
        actualizado.setContraseña("pwd");

        Mockito.when(usuarioService.updateUsuario(eq(1L), any(Usuario.class)))
               .thenReturn(actualizado);

        mockMvc.perform(put("/api/usuario/{id}", 1L)
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(cambios)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.correo", is("nuevo@mail.com")))
               .andExpect(jsonPath("$['contraseña']", is("pwd")));
    }

    @Test
    @DisplayName("DELETE /api/usuario/{id} → 204 No Content al eliminar")
    void eliminarUsuario() throws Exception {
        Mockito.doNothing().when(usuarioService).deleteUsuario(1L);

        mockMvc.perform(delete("/api/usuario/{id}", 1L))
               .andExpect(status().isNoContent());
    }



}
